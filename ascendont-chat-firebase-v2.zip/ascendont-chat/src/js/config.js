
 // MOBILE-FRIENDLY FIREBASE SETUP
// Firebase Console > Project settings > Your apps > Web app > Config.
// These are Firebase web configuration values, not service-account secrets.

export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyC363yJw-KrnoZk_hk80Nd_29F7Z242Ups",
  authDomain: "ascendont-chat.firebaseapp.com",
  projectId: "ascendont-chat",
  storageBucket: "ascendont-chat.firebasestorage.app",
  messagingSenderId: "695309955372",
  appId: "1:695309955372:web:eefa86fd7a7d555f417c89",
  measurementId: "G-9E5CMV3VWL"
};

export const isFirebaseConfigured = () =>
  Boolean(
    FIREBASE_CONFIG.apiKey &&
    FIREBASE_CONFIG.authDomain &&
    FIREBASE_CONFIG.projectId &&
    FIREBASE_CONFIG.storageBucket &&
    FIREBASE_CONFIG.messagingSenderId &&
    FIREBASE_CONFIG.appId &&
    !FIREBASE_CONFIG.apiKey.includes("YOUR_") &&
    !FIREBASE_CONFIG.projectId.includes("YOUR_") &&
    !FIREBASE_CONFIG.appId.includes("YOUR_")
  );