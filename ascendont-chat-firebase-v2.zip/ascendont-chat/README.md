# Ascendont Chat

Phone-first social web app built with HTML, CSS, vanilla JavaScript, Vite and Firebase. Designed for **SPCK Editor, GitHub, Vercel and Firebase using a phone only**.

## Firebase setup (no terminal required)

1. Open https://console.firebase.google.com/ and create/select a Firebase project.
2. In Project settings, add a **Web app** and copy its Firebase config object.
3. In SPCK Editor open `src/js/config.js`. Replace the placeholder values in `FIREBASE_CONFIG` with the values from your Firebase web app. Do not use a service-account private key.
4. In Firebase Console open **Authentication → Sign-in method** and enable **Email/Password**.
5. Open **Firestore Database → Create database**. Then open its Rules tab, copy `firestore.rules` from this repository into the editor, and Publish.
6. Open **Storage → Get started**. Copy `storage.rules` into Storage Rules and Publish. Firebase Storage may require a billing-enabled plan depending on your account and current Firebase terms; if Firebase asks for billing, don't enable it unless you accept the charges.
7. Push the changes to GitHub. In Vercel import the repository, select **Vite**, build command `npm run build`, output directory `dist`. Vercel installs and builds dependencies in the cloud.
8. Open your Vercel website URL on your phone.

## Collections

The app uses Firestore collections named `profiles`, `posts`, `follows`, `stories`, `story_highlights`, `comments`, `likes`, `saved_posts`, `conversations`, `conversation_members`, `messages`, `calls`, `notifications`, `account_settings`, `blocked_accounts`, and `verification_requests`. Documents are created by the app as users use features.

## Important limitations

- This is a Firebase migration foundation, not a guarantee of complete feature parity with Supabase. The compatibility layer covers basic reads/writes and email/password auth; Firestore does not provide SQL joins, so areas that relied on nested relational selects (profile details alongside posts, conversation joins, etc.) may need follow-up changes and testing.
- Realtime call signaling is not implemented in this migration. Video/voice calls require additional Firebase Realtime Database or Firestore signaling and WebRTC setup.
- Firebase rules here are a starting point for testing, not a complete production security audit. Tighten access controls before inviting real users.
- AI features require a separate secure backend/provider. Never put AI service secrets in frontend code.
- Never put a Firebase service-account private key in this repository. Firebase web config is designed for client apps; security comes from Authentication and rules.
- SPCK's single-file preview may not run Vite imports. Test the deployed Vercel URL instead.
